package com.example.oddsanalyzer

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import java.net.URI

data class Pick(val label: String, val odds: Double)
data class MarketResult(val name: String, val picks: List<Pick>, val impliedSum: Double)

class MainActivity : ComponentActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var url by remember { mutableStateOf("https://1xbet-bangladesh.mobi/en/betsonyour/line/football/54221-iran-azadegan-league/395091415-ario-eslamshahr-saipa") }
                var status by remember { mutableStateOf("لینک مسابقه را وارد و بارگذاری کن.") }
                var results by remember { mutableStateOf(listOf<MarketResult>()) }
                var webView by remember { mutableStateOf<WebView?>(null) }

                Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Text("Odds Analyzer 0.4", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(url, { url = it; results = emptyList() },
                        modifier = Modifier.fillMaxWidth(), label = { Text("لینک مسابقه") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val host = try { URI(url.trim()).host ?: "" } catch (_: Exception) { "" }
                            if (host != "1xbet-bangladesh.mobi" && !host.endsWith(".1xbet-bangladesh.mobi")) {
                                status = "فقط لینک دامنه 1xbet-bangladesh.mobi پذیرفته می‌شود."
                            } else {
                                results = emptyList()
                                status = "در حال بارگذاری لینک واردشده..."
                                webView?.loadUrl(url.trim())
                            }
                        }, modifier = Modifier.weight(1f)) { Text("بارگذاری مسابقه") }
                        Button(onClick = {
                            val w = webView
                            if (w == null) status = "ابتدا صفحه را بارگذاری کن."
                            else {
                                status = "در حال اسکن بازارهای قابل‌مشاهده..."
                                scan(w) { page ->
                                    results = OddsParser.parse(page)
                                    status = "استخراج تمام شد: ${results.size} بازار و ${results.sumOf { it.picks.size }} گزینه. نتیجه را با صفحه تطبیق بده."
                                    if (results.isEmpty()) status = "متن صفحه دریافت شد، اما بازار استانداردی شناسایی نشد."
                                }
                            }
                        }, modifier = Modifier.weight(1f)) { Text("اسکن ضرایب") }
                    }
                    Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().weight(0.48f),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.loadsImagesAutomatically = false
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView, loadedUrl: String?) {
                                        status = "صفحه مسابقه بارگذاری شد؛ اکنون اسکن ضرایب را بزن."
                                    }
                                }
                                webView = this
                            }
                        },
                        update = { webView = it }
                    )
                    Text("بازارهای استخراج‌شده", style = MaterialTheme.typography.titleMedium)
                    LazyColumn(Modifier.weight(0.52f)) {
                        items(results) { market ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(market.name, style = MaterialTheme.typography.titleMedium)
                                    market.picks.forEach { Text("${it.label}: ${it.odds}") }
                                    Text("مجموع احتمال ضمنی: ${"%.2f".format(market.impliedSum * 100)}٪")
                                    Text("حاشیه خام: ${"%.2f".format((market.impliedSum - 1) * 100)}٪")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun scan(wv: WebView, done: (String) -> Unit) {
        wv.addJavascriptInterface(object {
            @JavascriptInterface fun onText(value: String) { runOnUiThread { done(value) } }
        }, "OddsBridge")
        val js = """
            (function(){
              let i=0;
              function go(){
                window.scrollTo(0, document.body.scrollHeight);
                i++;
                if(i<16) setTimeout(go,450);
                else {
                  window.scrollTo(0,0);
                  setTimeout(function(){
                    OddsBridge.onText(document.body ? document.body.innerText : '');
                  },700);
                }
              }
              go();
            })();
        """.trimIndent()
        wv.evaluateJavascript(js, null)
    }
}

object OddsParser {
    private val row = Regex("""^(.{1,90}?)\s+([1-9]\d*(?:[.,]\d+)?)\s*$""")
    fun parse(text: String): List<MarketResult> {
        val output = mutableListOf<MarketResult>()
        var title = "بازار"
        var picks = mutableListOf<Pick>()
        fun flush() {
            if (picks.size >= 2) {
                output.add(MarketResult(title, picks.toList(), picks.sumOf { 1.0 / it.odds }))
            }
            picks = mutableListOf()
        }
        for (line0 in text.lines()) {
            val line = line0.trim().replace(Regex("\\s+"), " ")
            if (line.isBlank()) continue
            val m = row.matchEntire(line)
            if (m != null) {
                val label = m.groupValues[1].trim()
                val value = m.groupValues[2].replace(',', '.').toDoubleOrNull()
                if (value != null && value > 1.0 &&
                    !label.matches(Regex("""(?i)(over|under)\s+\d+(?:\.\d+)?"""))) {
                    picks.add(Pick(label, value))
                } else {
                    flush()
                    title = line
                }
            } else {
                flush()
                title = line.take(90)
            }
        }
        flush()
        return output.distinctBy { it.name + it.picks.joinToString { p -> p.label + p.odds } }
    }
}
